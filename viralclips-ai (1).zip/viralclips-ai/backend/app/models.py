from enum import Enum
from typing import Optional
from pydantic import BaseModel


class JobStatus(str, Enum):
    UPLOADED = "uploaded"
    TRANSCRIBING = "transcribing"
    ANALYZING = "analyzing"
    CLIPPING = "clipping"
    CAPTIONING = "captioning"
    DONE = "done"
    FAILED = "failed"


class ViralMoment(BaseModel):
    """One candidate short identified by the LLM inside the full transcript."""
    start_seconds: float
    end_seconds: float
    title: str          # short hook title suggested for the clip
    reason: str          # why this moment is expected to perform well
    hook_line: str        # the exact line that should appear as the opening caption


class Clip(BaseModel):
    id: str
    job_id: str
    moment: ViralMoment
    video_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    caption_style: str = "bold-yellow"
    status: JobStatus = JobStatus.UPLOADED


class Job(BaseModel):
    id: str
    user_id: str
    source_video_url: str
    status: JobStatus = JobStatus.UPLOADED
    progress_percent: int = 0
    clips: list[Clip] = []
    error: Optional[str] = None
