"""
Step 3 — Clipping + vertical reframe
--------------------------------------
Cuts each ViralMoment out of the source video and reframes it from
landscape/whatever-ratio into 9:16 vertical, centered on the most likely
"subject" of the frame (a naive center-crop by default; swap the crop_x_expr
for a face-tracking pass once you want smarter framing).

ffmpeg is used directly via subprocess for full control - the `ffmpeg-python`
wrapper gets in the way once filters get this specific.
"""

import subprocess
from pathlib import Path

from app.models import ViralMoment

TARGET_W, TARGET_H = 1080, 1920  # 9:16


def cut_and_reframe(
    source_path: str,
    moment: ViralMoment,
    output_path: str,
    face_track_crop_x: float | None = None,
) -> str:
    """
    face_track_crop_x: optional 0.0-1.0 horizontal position (as a fraction of
    source width) to center the vertical crop on. Feed this from a face
    detection pass (e.g. MediaPipe) upstream for "smart" framing. Falls back
    to a plain center crop when not provided.
    """
    duration = moment.end_seconds - moment.start_seconds

    # Scale so height fills 1920, then crop width down to 1080 around the
    # chosen horizontal center.
    if face_track_crop_x is not None:
        crop_x_expr = f"(iw-{TARGET_W})*{face_track_crop_x}"
    else:
        crop_x_expr = f"(iw-{TARGET_W})/2"

    vf = (
        f"scale=-2:{TARGET_H},"
        f"crop={TARGET_W}:{TARGET_H}:{crop_x_expr}:0"
    )

    cmd = [
        "ffmpeg", "-y",
        "-ss", str(moment.start_seconds),
        "-i", source_path,
        "-t", str(duration),
        "-vf", vf,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-c:a", "aac", "-b:a", "128k",
        output_path,
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return output_path


def make_thumbnail(clip_path: str, thumbnail_path: str, at_second: float = 0.5) -> str:
    cmd = [
        "ffmpeg", "-y",
        "-ss", str(at_second),
        "-i", clip_path,
        "-frames:v", "1",
        thumbnail_path,
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return thumbnail_path
