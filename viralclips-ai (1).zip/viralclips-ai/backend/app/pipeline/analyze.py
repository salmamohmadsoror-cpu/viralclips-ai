"""
Step 2 — Viral moment detection
--------------------------------
This is the "secret sauce" of the product: an LLM reads the timestamped
transcript and picks the N segments most likely to work as standalone shorts.

Design notes:
- We ask for STRICT JSON back so it can be parsed with zero ambiguity.
- We ask the model to reason about hooks (first 1-2 seconds), emotional
  peaks, and self-contained payoff (a short must make sense with no context
  from the rest of the video).
- We cap each clip's length (15-90s is the sweet spot for Shorts/Reels/TikTok).
"""

import json
from anthropic import Anthropic

from app.config import settings
from app.models import ViralMoment
from app.pipeline.transcribe import Transcript

client = Anthropic(api_key=settings.anthropic_api_key)

SYSTEM_PROMPT = """You are an expert short-form video editor who has produced \
hundreds of viral TikTok/Reels/Shorts clips from long-form podcasts and talks.

You will receive a timestamped transcript of a long video. Identify the \
{n} segments most likely to go viral as standalone short clips.

Rules for each segment:
- Duration between 15 and 90 seconds.
- Must have a strong HOOK in its first 1-2 seconds (a question, bold claim, \
  surprising statement, or emotional spike) - this line becomes the opening \
  on-screen caption.
- Must be self-contained: a viewer with zero context should understand it.
- Prefer moments with a clear payoff, a punchline, a strong opinion, or \
  useful actionable advice.
- Do not let segments overlap.

Respond with ONLY a JSON array, no prose, no markdown fences. Each item:
{{"start_seconds": float, "end_seconds": float, "title": "short catchy title", \
"reason": "one sentence on why this will perform well", \
"hook_line": "the exact opening line to feature as the first caption"}}
"""


def find_viral_moments(transcript: Transcript, n: int = 10) -> list[ViralMoment]:
    timestamped_lines = "\n".join(
        f"[{w.start:.2f}] {w.text}" for w in transcript.words
    )

    message = client.messages.create(
        model="claude-sonnet-5",
        max_tokens=4000,
        system=SYSTEM_PROMPT.format(n=n),
        messages=[{"role": "user", "content": timestamped_lines}],
    )

    raw_text = "".join(
        block.text for block in message.content if block.type == "text"
    ).strip()

    data = json.loads(raw_text)
    return [ViralMoment(**item) for item in data]
