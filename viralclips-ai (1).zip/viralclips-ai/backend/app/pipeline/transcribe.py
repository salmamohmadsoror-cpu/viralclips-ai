"""
Step 1 — Transcription
-----------------------
Turns the source video into a transcript with WORD-LEVEL timestamps.
Word-level timing (not just sentence-level) is what lets step 4 (captions.py)
draw the "karaoke" word-by-word highlight effect.

Uses OpenAI's Whisper API (`verbose_json` gives us word timestamps).
Swap this out for a self-hosted faster-whisper if you want to cut API costs
once volume grows.
"""

from dataclasses import dataclass
from openai import OpenAI

from app.config import settings

client = OpenAI(api_key=settings.openai_api_key)


@dataclass
class Word:
    text: str
    start: float
    end: float


@dataclass
class Transcript:
    full_text: str
    words: list[Word]

    def text_between(self, start: float, end: float) -> str:
        """Handy helper used by analyze.py to show the LLM only a slice."""
        return " ".join(w.text for w in self.words if start <= w.start <= end)


def transcribe_video(local_video_path: str) -> Transcript:
    with open(local_video_path, "rb") as f:
        response = client.audio.transcriptions.create(
            model="whisper-1",
            file=f,
            response_format="verbose_json",
            timestamp_granularities=["word"],
        )

    words = [
        Word(text=w["word"], start=w["start"], end=w["end"])
        for w in response.words
    ]
    return Transcript(full_text=response.text, words=words)
