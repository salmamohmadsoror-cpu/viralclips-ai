"""
Step 4 — Animated word-by-word captions
------------------------------------------
Builds an .ass subtitle file where EACH WORD is its own timed event, so
playback shows one word highlighted at a time (the "TikTok/CapCut karaoke"
look), then burns it into the clip with ffmpeg's subtitles filter.

Why .ass and not .srt: .ass supports per-cue styling (color, outline, position)
which is what makes the bold-highlighted-word effect possible. SRT can't do it.
"""

import subprocess
from dataclasses import dataclass

from app.pipeline.transcribe import Word

CAPTION_STYLES = {
    "bold-yellow": dict(font="Montserrat Black", size=90, primary="&H0000FFFF", outline="&H00000000"),
    "bold-white": dict(font="Montserrat Black", size=90, primary="&H00FFFFFF", outline="&H00000000"),
    "pink-pop": dict(font="Montserrat Black", size=90, primary="&H00A66DFF", outline="&H00000000"),
}


def _ass_timestamp(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h:d}:{m:02d}:{s:05.2f}"


def build_ass_file(words: list[Word], clip_start: float, clip_end: float,
                    style: str, out_path: str) -> str:
    cfg = CAPTION_STYLES[style]
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, Bold, Outline, Shadow, Alignment, MarginV
Style: Word,{cfg['font']},{cfg['size']},{cfg['primary']},{cfg['outline']},1,4,0,2,300

[Events]
Format: Layer, Start, End, Style, Text
"""
    lines = []
    for w in words:
        if w.start < clip_start or w.end > clip_end:
            continue
        rel_start = w.start - clip_start
        rel_end = w.end - clip_start
        # small pad so consecutive words don't leave a visible gap
        lines.append(
            f"Dialogue: 0,{_ass_timestamp(rel_start)},{_ass_timestamp(rel_end)},"
            f"Word,,0,0,0,,{w.text.strip().upper()}"
        )

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(header + "\n".join(lines))
    return out_path


def burn_captions(clip_path: str, ass_path: str, output_path: str) -> str:
    cmd = [
        "ffmpeg", "-y",
        "-i", clip_path,
        "-vf", f"subtitles={ass_path}",
        "-c:a", "copy",
        output_path,
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return output_path
