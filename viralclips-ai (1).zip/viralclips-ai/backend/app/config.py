from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    openai_api_key: str = ""
    anthropic_api_key: str = ""

    s3_endpoint_url: str = ""
    s3_access_key_id: str = ""
    s3_secret_access_key: str = ""
    s3_bucket_name: str = "viralclips-ai"
    s3_region: str = "auto"

    database_url: str = "postgresql://postgres:postgres@localhost:5432/viralclips"
    redis_url: str = "redis://localhost:6379/0"

    app_env: str = "development"
    max_upload_minutes: int = 10
    clips_per_video: int = 10

    class Config:
        env_file = ".env"


settings = Settings()
