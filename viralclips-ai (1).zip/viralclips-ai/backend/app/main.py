"""
API layer
----------
Thin FastAPI app exposing the endpoints the frontend's 5 screens need:

  POST /jobs                 - upload a video, kicks off processing (async)
  GET  /jobs/{job_id}        - poll status/progress (used by the Processing screen)
  GET  /jobs/{job_id}/clips  - list the 10 generated clips (Results screen)
  PATCH /clips/{clip_id}     - change caption style / re-render (Editor screen)

Heavy work (transcribe -> analyze -> clip -> caption) runs in a background
task queue (Celery/BullMQ-equivalent) in production - here it's shown as a
FastAPI BackgroundTask for clarity; swap `process_job` to a Celery task
(see pipeline/__init__.py docstring) once you have real traffic.
"""

import uuid
from pathlib import Path

from fastapi import FastAPI, UploadFile, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.models import Job, Clip, JobStatus
from app.pipeline.transcribe import transcribe_video
from app.pipeline.analyze import find_viral_moments
from app.pipeline.clip import cut_and_reframe, make_thumbnail
from app.pipeline.captions import build_ass_file, burn_captions

app = FastAPI(title="ViralClips AI")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to your frontend domain in production
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory store for the demo - replace with Postgres (SQLAlchemy) in prod.
JOBS: dict[str, Job] = {}
UPLOAD_DIR = Path("/tmp/viralclips_uploads")
UPLOAD_DIR.mkdir(exist_ok=True)


def process_job(job_id: str):
    job = JOBS[job_id]
    try:
        source_path = str(UPLOAD_DIR / f"{job_id}.mp4")

        job.status = JobStatus.TRANSCRIBING
        job.progress_percent = 10
        transcript = transcribe_video(source_path)

        job.status = JobStatus.ANALYZING
        job.progress_percent = 35
        moments = find_viral_moments(transcript, n=settings.clips_per_video)

        job.status = JobStatus.CLIPPING
        clips: list[Clip] = []
        for i, moment in enumerate(moments):
            clip_id = f"{job_id}-{i}"
            raw_clip_path = str(UPLOAD_DIR / f"{clip_id}_raw.mp4")
            final_clip_path = str(UPLOAD_DIR / f"{clip_id}_final.mp4")
            thumb_path = str(UPLOAD_DIR / f"{clip_id}_thumb.jpg")
            ass_path = str(UPLOAD_DIR / f"{clip_id}.ass")

            cut_and_reframe(source_path, moment, raw_clip_path)

            job.status = JobStatus.CAPTIONING
            build_ass_file(
                transcript.words, moment.start_seconds, moment.end_seconds,
                style="bold-yellow", out_path=ass_path,
            )
            burn_captions(raw_clip_path, ass_path, final_clip_path)
            make_thumbnail(final_clip_path, thumb_path)

            clips.append(Clip(
                id=clip_id, job_id=job_id, moment=moment,
                video_url=f"/media/{clip_id}_final.mp4",
                thumbnail_url=f"/media/{clip_id}_thumb.jpg",
                status=JobStatus.DONE,
            ))
            job.progress_percent = 35 + int(60 * (i + 1) / len(moments))

        job.clips = clips
        job.status = JobStatus.DONE
        job.progress_percent = 100

    except Exception as e:
        job.status = JobStatus.FAILED
        job.error = str(e)


@app.post("/jobs", response_model=Job)
async def create_job(background_tasks: BackgroundTasks, file: UploadFile):
    job_id = str(uuid.uuid4())
    dest = UPLOAD_DIR / f"{job_id}.mp4"
    with open(dest, "wb") as out:
        out.write(await file.read())

    job = Job(id=job_id, user_id="demo-user", source_video_url=str(dest))
    JOBS[job_id] = job

    background_tasks.add_task(process_job, job_id)
    return job


@app.get("/jobs/{job_id}", response_model=Job)
async def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job


@app.get("/jobs/{job_id}/clips", response_model=list[Clip])
async def get_clips(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job.clips
