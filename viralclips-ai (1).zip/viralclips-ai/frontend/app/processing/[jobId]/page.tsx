import Sidebar from "@/components/Sidebar";
import { Check, Loader2 } from "lucide-react";

const STEPS = [
  { key: "transcribing", label: "Listening to your video" },
  { key: "analyzing", label: "Finding the 10 best moments" },
  { key: "clipping", label: "Cutting and reframing to vertical" },
  { key: "captioning", label: "Animating the captions" },
];

// In production this reads live status from GET /jobs/{jobId} (polling or SSE).
const CURRENT_STEP_INDEX = 1;

export default function ProcessingPage({ params }: { params: { jobId: string } }) {
  return (
    <main className="flex min-h-screen bg-base">
      <Sidebar active="dashboard" />

      <section className="flex-1 flex items-center justify-center p-10">
        <div className="w-full max-w-md">
          <h1 className="font-display text-2xl font-bold mb-1 text-center">
            Cutting your clips
          </h1>
          <p className="text-muted text-sm text-center mb-10">
            This usually takes 3-5 minutes for a 10-minute video.
          </p>

          <div className="flex flex-col gap-4">
            {STEPS.map((step, i) => {
              const done = i < CURRENT_STEP_INDEX;
              const active = i === CURRENT_STEP_INDEX;
              return (
                <div
                  key={step.key}
                  className={`flex items-center gap-4 rounded-card border px-5 py-4 ${
                    active ? "border-volt bg-elevated" : "border-border bg-surface"
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                      done ? "bg-go" : active ? "bg-volt" : "bg-elevated"
                    }`}
                  >
                    {done ? (
                      <Check size={16} className="text-base" />
                    ) : active ? (
                      <Loader2 size={16} className="animate-spin" />
                    ) : (
                      <span className="text-xs text-muted">{i + 1}</span>
                    )}
                  </div>
                  <p className={`text-sm ${done || active ? "text-ink" : "text-muted"} font-medium`}>
                    {step.label}
                  </p>
                </div>
              );
            })}
          </div>

          <p className="text-xs text-muted text-center mt-8">
            Feel free to close this tab - we'll email you when job {params.jobId} is ready.
          </p>
        </div>
      </section>
    </main>
  );
}
