import { Scissors } from "lucide-react";

export default function LoginPage() {
  return (
    <main className="min-h-screen grid grid-cols-1 md:grid-cols-2">
      {/* Left: pitch */}
      <div className="hidden md:flex flex-col justify-between p-12 bg-surface border-r border-border">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-record record-dot" />
          <span className="font-display font-bold text-lg">ViralClips</span>
        </div>

        <div className="max-w-md">
          <h1 className="font-display text-4xl leading-tight font-bold mb-4">
            One long video in.
            <br />
            Ten short clips out.
          </h1>
          <p className="text-muted text-base leading-relaxed">
            Upload a 10-minute talk, podcast, or video. ViralClips AI finds
            the ten moments most likely to hook a scroller, cuts them to
            vertical, and captions every word.
          </p>
        </div>

        <p className="text-xs text-muted">© 2026 ViralClips AI</p>
      </div>

      {/* Right: auth form */}
      <div className="flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="flex items-center gap-2 mb-10 md:hidden">
            <span className="w-2.5 h-2.5 rounded-full bg-record record-dot" />
            <span className="font-display font-bold text-lg">ViralClips</span>
          </div>

          <h2 className="font-display text-2xl font-bold mb-1">Welcome back</h2>
          <p className="text-muted text-sm mb-8">Sign in to keep cutting clips.</p>

          <form className="flex flex-col gap-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Email</label>
              <input
                type="email"
                placeholder="you@studio.com"
                className="w-full rounded-card bg-elevated border border-border px-4 py-3 text-sm outline-none focus:border-volt"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Password</label>
              <input
                type="password"
                placeholder="••••••••"
                className="w-full rounded-card bg-elevated border border-border px-4 py-3 text-sm outline-none focus:border-volt"
              />
            </div>
            <button
              type="submit"
              className="mt-2 w-full rounded-card bg-record py-3 text-sm font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            >
              <Scissors size={16} />
              Sign in
            </button>
          </form>

          <p className="text-xs text-muted mt-6 text-center">
            New here? <a href="#" className="text-ink underline">Create an account</a>
          </p>
        </div>
      </div>
    </main>
  );
}
