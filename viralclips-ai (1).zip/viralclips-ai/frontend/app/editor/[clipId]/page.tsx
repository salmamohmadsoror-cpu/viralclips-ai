import Sidebar from "@/components/Sidebar";
import { Play, Download, Share2 } from "lucide-react";

const CAPTION_STYLES = [
  { id: "bold-yellow", label: "Bold yellow", swatch: "#FFD400" },
  { id: "bold-white", label: "Bold white", swatch: "#FFFFFF" },
  { id: "pink-pop", label: "Pink pop", swatch: "#A66DFF" },
];

export default function EditorPage({ params }: { params: { clipId: string } }) {
  return (
    <main className="flex min-h-screen bg-base">
      <Sidebar active="dashboard" />

      <section className="flex-1 p-10 grid grid-cols-1 lg:grid-cols-[360px_1fr] gap-10">
        {/* Preview */}
        <div>
          <div className="aspect-[9/16] w-full max-w-sm rounded-card bg-elevated border border-border flex items-center justify-center relative overflow-hidden">
            <Play size={32} className="text-muted" />
            <div className="absolute bottom-10 left-0 right-0 text-center px-6">
              <span className="font-display font-bold text-2xl bg-black/40 px-2 py-1 rounded">
                YOU'RE PRICING
              </span>
            </div>
          </div>
          <p className="text-xs text-muted mt-3">Clip {params.clipId} · 00:34</p>
        </div>

        {/* Controls */}
        <div className="max-w-md">
          <h1 className="font-display text-2xl font-bold mb-1">Edit &amp; export</h1>
          <p className="text-muted text-sm mb-8">Adjust the caption style, then export or share.</p>

          <h2 className="text-sm font-semibold mb-3">Caption style</h2>
          <div className="flex gap-3 mb-8">
            {CAPTION_STYLES.map((style) => (
              <button
                key={style.id}
                className="flex-1 rounded-card border border-border bg-surface hover:border-volt transition-colors p-4 flex flex-col items-center gap-2"
              >
                <span
                  className="w-6 h-6 rounded-full border border-border"
                  style={{ backgroundColor: style.swatch }}
                />
                <span className="text-xs font-medium">{style.label}</span>
              </button>
            ))}
          </div>

          <h2 className="text-sm font-semibold mb-3">Title</h2>
          <input
            defaultValue="You're pricing this wrong"
            className="w-full rounded-card bg-elevated border border-border px-4 py-3 text-sm outline-none focus:border-volt mb-8"
          />

          <div className="flex gap-3">
            <button className="flex-1 rounded-card bg-record py-3 text-sm font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
              <Download size={16} />
              Download
            </button>
            <button className="flex-1 rounded-card border border-border py-3 text-sm font-semibold hover:border-volt transition-colors flex items-center justify-center gap-2">
              <Share2 size={16} />
              Share
            </button>
          </div>
        </div>
      </section>
    </main>
  );
}
