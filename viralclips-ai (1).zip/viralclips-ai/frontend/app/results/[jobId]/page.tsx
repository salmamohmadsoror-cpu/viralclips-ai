import Sidebar from "@/components/Sidebar";
import { Play, Download } from "lucide-react";

const CLIPS = Array.from({ length: 10 }).map((_, i) => ({
  id: `clip_${i}`,
  title: [
    "You're pricing this wrong",
    "The mistake every founder makes",
    "Why I fired my first hire",
    "This changed how I sell",
    "Nobody tells you this part",
    "The $1k month that mattered most",
    "Stop doing this in meetings",
    "The question that closed the deal",
    "Why slow growth won",
    "The line that got the loudest reaction",
  ][i],
  score: 90 - i * 3,
}));

export default function ResultsPage({ params }: { params: { jobId: string } }) {
  return (
    <main className="flex min-h-screen bg-base">
      <Sidebar active="dashboard" />

      <section className="flex-1 p-10">
        <header className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold mb-1">10 clips are ready</h1>
            <p className="text-muted text-sm">From job {params.jobId} · sorted by predicted performance</p>
          </div>
          <button className="rounded-card border border-border px-5 py-2.5 text-sm font-medium hover:border-volt transition-colors flex items-center gap-2">
            <Download size={16} />
            Download all
          </button>
        </header>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-5">
          {CLIPS.map((clip, i) => (
            <a
              key={clip.id}
              href={`/editor/${clip.id}`}
              className="group rounded-card overflow-hidden border border-border bg-surface hover:border-volt transition-colors"
            >
              <div className="relative aspect-[9/16] bg-elevated flex items-center justify-center">
                <Play className="text-muted group-hover:text-ink transition-colors" size={28} />
                <span className="absolute top-2 left-2 text-[10px] font-semibold bg-base/80 rounded px-1.5 py-0.5">
                  #{i + 1}
                </span>
                <span className="absolute top-2 right-2 text-[10px] font-semibold bg-record rounded px-1.5 py-0.5">
                  {clip.score}%
                </span>
              </div>
              <div className="p-3">
                <p className="text-xs font-medium leading-snug line-clamp-2">{clip.title}</p>
              </div>
            </a>
          ))}
        </div>
      </section>
    </main>
  );
}
