# ViralClips AI

Upload a 10-minute video → get back 10 vertical short clips with animated,
word-by-word captions.

## Structure

```
backend/     FastAPI + the processing pipeline (transcribe → analyze → clip → caption)
frontend/    Next.js app - the 5 screens (login, dashboard, processing, results, editor)
```

## Backend — run locally

```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in OPENAI_API_KEY and ANTHROPIC_API_KEY
uvicorn app.main:app --reload --port 8000
```

Requires `ffmpeg` installed on the machine (`brew install ffmpeg` / `apt install ffmpeg`).

Test the pipeline end to end:
```bash
curl -X POST http://localhost:8000/jobs -F "file=@/path/to/video.mp4"
curl http://localhost:8000/jobs/<job_id>
```

## Frontend — run locally

```bash
cd frontend
npm install
npm run dev
```

Opens on http://localhost:3000. Screens: `/login`, `/` (dashboard), `/processing/[jobId]`,
`/results/[jobId]`, `/editor/[clipId]`.

## What's real vs. a stub here

- **Real, working logic**: the whole pipeline in `backend/app/pipeline/` — Whisper
  transcription, the Claude prompt that finds viral moments, the ffmpeg commands for
  cropping to 9:16 and burning in karaoke-style captions.
- **Stubbed for the demo**: job storage is in-memory (`JOBS` dict in `main.py`) instead
  of Postgres, and processing runs as a FastAPI background task instead of a real queue
  (Celery/BullMQ). Swap those in before real users hit it — see comments in `main.py`.
- **Frontend**: the 5 screens are built with mock/sample data wired up visually; connect
  them to the API above (`fetch('/jobs', ...)`, poll `/jobs/{id}`, etc.) to make it live.

## Suggested build order

1. Get the backend pipeline working end-to-end on your own test video from the CLI.
2. Wire the dashboard's upload button to `POST /jobs`.
3. Poll `GET /jobs/{id}` on the processing screen until `status === "done"`.
4. Fetch `GET /jobs/{id}/clips` on the results screen.
5. Add Postgres + Celery once you have real users and can't rely on in-memory state.

## Push to GitHub

```bash
cd viralclips-ai
git init
git add .
git commit -m "Initial commit - ViralClips AI scaffold"
git branch -M main
git remote add origin https://github.com/<your-username>/viralclips-ai.git
git push -u origin main
```

`.gitignore` already excludes `node_modules/`, `venv/`, `.env`, `.next/`, and any local
video files, so secrets and build artifacts won't get committed by accident.

