"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import UploadZone from "@/components/UploadZone";
import { listProjects, uploadVideo, type Project } from "@/lib/api";

const STATUS_LABEL: Record<Project["status"], string> = {
  uploading: "بيترفع",
  transcribing: "قيد المعالجة",
  analyzing: "قيد المعالجة",
  rendering: "قيد المعالجة",
  ready: "جاهز",
  failed: "فشلت المعالجة"
};

export default function DashboardPage() {
  const router = useRouter();
  const [projects, setProjects] = useState<Project[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  useEffect(() => {
    listProjects()
      .then(setProjects)
      .catch(() => setProjects([]));
  }, []);

  async function handleUpload(file: File) {
    setIsUploading(true);
    setUploadError(null);
    try {
      const { projectId } = await uploadVideo(file);
      router.push(`/processing/${projectId}`);
    } catch (err) {
      setUploadError(
        err instanceof Error ? err.message : "حصل خطأ غير متوقع أثناء الرفع."
      );
    } finally {
      setIsUploading(false);
    }
  }

  return (
    <main>
      <Navbar />
      <div className="mx-auto max-w-4xl px-6 py-12">
        <h1 className="font-display text-2xl font-bold">ارفع فيديو جديد</h1>
        <p className="mt-1 text-sm text-paper/50">
          هيتم تحويله لعشر شورتس تلقائيًا.
        </p>

        <div className="mt-8">
          <UploadZone onFileSelected={handleUpload} isUploading={isUploading} />
          {uploadError && (
            <p className="mt-3 text-sm text-pulse">{uploadError}</p>
          )}
        </div>

        <h2 className="mt-16 font-display text-lg font-medium">
          مشاريعك السابقة
        </h2>

        {projects.length === 0 ? (
          <p className="mt-4 text-sm text-paper/40">
            لسه معملتش أي مشروع. ارفع أول فيديو وهيظهر هنا.
          </p>
        ) : (
          <div className="mt-4 divide-y divide-line rounded-clip border border-line">
            {projects.map((project) => (
              <button
                key={project.id}
                onClick={() =>
                  router.push(
                    project.status === "ready"
                      ? `/results/${project.id}`
                      : `/processing/${project.id}`
                  )
                }
                className="flex w-full items-center justify-between px-4 py-4 text-right hover:bg-panel"
              >
                <span className="text-sm">{project.sourceFileName}</span>
                <span
                  className={`text-xs ${
                    project.status === "ready"
                      ? "text-signal"
                      : project.status === "failed"
                      ? "text-pulse"
                      : "text-paper/40"
                  }`}
                >
                  {STATUS_LABEL[project.status]}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
