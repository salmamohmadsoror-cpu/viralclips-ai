"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import ProgressSteps from "@/components/ProgressSteps";
import { getProject, type Project } from "@/lib/api";

const POLL_INTERVAL_MS = 4000;

export default function ProcessingPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [project, setProject] = useState<Project | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout>;

    async function poll() {
      try {
        const data = await getProject(id);
        if (cancelled) return;
        setProject(data);

        if (data.status === "ready") {
          router.push(`/results/${id}`);
          return;
        }
        if (data.status === "failed") {
          setError("حصلت مشكلة أثناء معالجة الفيديو. جرب ترفعه تاني.");
          return;
        }
        timer = setTimeout(poll, POLL_INTERVAL_MS);
      } catch {
        if (!cancelled) {
          timer = setTimeout(poll, POLL_INTERVAL_MS);
        }
      }
    }

    poll();
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [id, router]);

  return (
    <main>
      <Navbar />
      <div className="mx-auto flex max-w-4xl flex-col items-center px-6 py-24 text-center">
        <h1 className="font-display text-2xl font-bold">
          بنجهزلك الشورتس دلوقتي
        </h1>
        <p className="mt-2 text-sm text-paper/50">
          العملية بتاخد من 3 لـ 8 دقايق حسب طول الفيديو.
        </p>

        <div className="mt-12">
          <ProgressSteps status={project?.status ?? "uploading"} />
        </div>

        {error && (
          <div className="mt-10 rounded-clip border border-pulse/40 bg-pulse/5 px-4 py-3 text-sm text-pulse">
            {error}
          </div>
        )}
      </div>
    </main>
  );
}
