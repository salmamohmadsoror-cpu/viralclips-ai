"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import ClipCard from "@/components/ClipCard";
import { getProject, type Project } from "@/lib/api";

export default function ResultsPage() {
  const { id } = useParams<{ id: string }>();
  const [project, setProject] = useState<Project | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getProject(id)
      .then(setProject)
      .catch(() => setError("مقدرناش نجيب نتايج المشروع ده."));
  }, [id]);

  return (
    <main>
      <Navbar />
      <div className="mx-auto max-w-6xl px-6 py-12">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold">الشورتس جاهزة</h1>
            <p className="mt-1 text-sm text-paper/50">
              {project ? `${project.clips.length} كليب من ${project.sourceFileName}` : "..."}
            </p>
          </div>
          {project && project.clips.length > 0 && (
            <button className="rounded-clip bg-pulse px-4 py-2 text-sm font-medium text-ink hover:bg-[#ff5c7e]">
              تحميل الكل
            </button>
          )}
        </div>

        {error && <p className="mt-8 text-sm text-pulse">{error}</p>}

        {project && (
          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {project.clips.map((clip) => (
              <ClipCard key={clip.id} clip={clip} />
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
