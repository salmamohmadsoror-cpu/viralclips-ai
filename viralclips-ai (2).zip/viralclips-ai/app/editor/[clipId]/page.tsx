"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import CaptionStylePicker from "@/components/CaptionStylePicker";
import Button from "@/components/Button";
import { exportClip, updateClip } from "@/lib/api";

export default function EditorPage() {
  const { clipId } = useParams<{ clipId: string }>();
  const router = useRouter();

  const [title, setTitle] = useState("");
  const [captionStyle, setCaptionStyle] = useState("bold");
  const [isSaving, setIsSaving] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  async function handleSave() {
    setIsSaving(true);
    try {
      await updateClip(clipId, { title, captionStyle });
    } finally {
      setIsSaving(false);
    }
  }

  async function handleExport() {
    setIsExporting(true);
    try {
      const { downloadUrl } = await exportClip(clipId);
      setDownloadUrl(downloadUrl);
    } finally {
      setIsExporting(false);
    }
  }

  return (
    <main>
      <Navbar />
      <div className="mx-auto max-w-4xl px-6 py-12">
        <button
          onClick={() => router.back()}
          className="mb-6 text-sm text-paper/50 hover:text-paper"
        >
          → رجوع للنتايج
        </button>

        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2">
          <div className="aspect-[9/16] rounded-clip border border-line bg-panel" />

          <div className="space-y-8">
            <div>
              <label className="mb-2 block text-sm text-paper/70">
                عنوان الكليب
              </label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="اكتب عنوان جذاب للكليب"
                className="w-full rounded-clip border border-line bg-panel px-4 py-3 text-sm outline-none focus:border-signal"
              />
            </div>

            <CaptionStylePicker value={captionStyle} onChange={setCaptionStyle} />

            <div className="flex gap-3 pt-4">
              <Button variant="ghost" onClick={handleSave} disabled={isSaving}>
                {isSaving ? "بيتحفظ..." : "حفظ التعديلات"}
              </Button>
              <Button onClick={handleExport} disabled={isExporting}>
                {isExporting ? "بيتصدّر..." : "Export"}
              </Button>
            </div>

            {downloadUrl && (
              <a
                href={downloadUrl}
                download
                className="block text-sm text-signal underline"
              >
                تحميل الكليب النهائي
              </a>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
